<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Session;
use App\UserLoginModel;
class UserLoginController extends Controller
{
    public function login($username='',$password='',$date='',$countrycode='',$langauge='') {
    	echo $username . " " . $password . " " . $date . " " . $countrycode . " " .$langauge;exit; 
        $username = base64_decode($username);
        $password = base64_decode($password);
        $date = base64_decode($date);
        $countrycode = base64_decode($countrycode);
        $langauge = base64_decode($langauge);
        $where = array();
        $where['username'] = $username;
        $where['password'] = $password;
        $where['logindate'] = $date;
        $where['isactive'] = 1;
        $response = UserLoginModel::where($where)->get();
        if(!empty($response) && count($response) > 0) {
        	Session::put('name',$response[0]['name']);
        	Session::put('username',$response[0]['username']);
        	return view('home');
        } else {
        	echo "Invalid Credentials";
        }
    }
}
